require 'curb_core'
require 'curl'
require 'curl/easy'
require 'curl/multi'
